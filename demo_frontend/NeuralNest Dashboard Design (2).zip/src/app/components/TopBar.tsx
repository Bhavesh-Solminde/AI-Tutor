import React, { useState, useEffect } from 'react';
import { Search, Bell, Sun, Moon, HelpCircle } from 'lucide-react';

export function TopBar() {
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    setIsDark(document.documentElement.classList.contains('dark'));
  }, []);

  const toggleTheme = () => {
    const root = document.documentElement;
    if (root.classList.contains('dark')) {
      root.classList.remove('dark');
      setIsDark(false);
    } else {
      root.classList.add('dark');
      setIsDark(true);
    }
  };

  return (
    <header className="h-[72px] shrink-0 border-b border-nn-border bg-nn-bg-card flex items-center justify-between px-6 transition-colors">
      <div className="relative w-80">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-nn-text-muted" />
        <input 
          type="text" 
          placeholder="Search topics, chats, or notes..." 
          className="w-full bg-nn-bg-sidebar border border-nn-border text-sm text-nn-text-primary rounded-full py-2 pl-10 pr-4 outline-none focus:border-[#3B6BFF] transition-colors placeholder:text-nn-text-muted"
        />
      </div>

      <div className="flex items-center gap-5">
        <button className="flex items-center gap-2 bg-nn-bg-card border border-[#3B6BFF]/30 hover:border-[#3B6BFF] text-[#3B6BFF] px-4 py-1.5 rounded-full text-sm font-medium transition-all shadow-[0_1px_3px_rgba(0,0,0,0.08)] dark:shadow-[0_0_10px_rgba(59,107,255,0.1)]">
          <HelpCircle size={16} />
          Ask Doubt
        </button>

        <div className="flex items-center gap-2 border-r border-nn-border pr-5">
          <button className="p-2 text-nn-text-muted hover:text-nn-text-primary hover:bg-nn-bg-sidebar rounded-full transition-colors relative">
            <Bell size={20} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#3B6BFF] rounded-full ring-2 ring-nn-bg-card"></span>
          </button>
          <button onClick={toggleTheme} className="p-2 text-nn-text-muted hover:text-nn-text-primary hover:bg-nn-bg-sidebar rounded-full transition-colors">
            {isDark ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>

        <button className="flex items-center gap-3 hover:opacity-80 transition-opacity text-left">
          <img 
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64&q=80" 
            alt="User profile" 
            className="w-9 h-9 rounded-full object-cover ring-2 ring-nn-border"
          />
          <div className="hidden sm:block">
            <p className="text-sm font-semibold text-nn-text-primary leading-tight">Sarah Jenkins</p>
            <p className="text-xs text-nn-text-muted leading-tight">sarah@example.com</p>
          </div>
        </button>
      </div>
    </header>
  );
}