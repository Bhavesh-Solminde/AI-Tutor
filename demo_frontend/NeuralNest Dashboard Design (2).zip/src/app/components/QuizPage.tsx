import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Heart, Zap, CheckCircle, ArrowRight } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';

interface Question {
  id: number;
  label: string;
  text: string;
  options: string[];
  correctIndex: number;
}

const QUESTIONS: Question[] = [
  {
    id: 1,
    label: "Newton's Laws",
    text: "Which of the following best describes Newton's Second Law of Motion?",
    options: [
      "An object at rest stays at rest unless acted upon by an external force.",
      "The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass.",
      "For every action, there is an equal and opposite reaction.",
      "The velocity of an object remains constant if no net force acts on it.",
    ],
    correctIndex: 1,
  },
  {
    id: 2,
    label: 'Work & Energy',
    text: 'A 5 kg block is pushed 4 m along a frictionless surface by a 20 N force. What is the work done?',
    options: ['40 J', '80 J', '100 J', '160 J'],
    correctIndex: 1,
  },
  {
    id: 3,
    label: 'Kinematics',
    text: 'An object is dropped from rest. How far does it fall in 3 seconds? (g = 10 m/s²)',
    options: ['15 m', '30 m', '45 m', '90 m'],
    correctIndex: 2,
  },
  {
    id: 4,
    label: 'Waves',
    text: 'Which property of a wave determines its pitch when heard as sound?',
    options: ['Amplitude', 'Wavelength', 'Frequency', 'Speed'],
    correctIndex: 2,
  },
  {
    id: 5,
    label: 'Thermodynamics',
    text: 'Which law of thermodynamics states that energy cannot be created or destroyed?',
    options: ['Zeroth Law', 'First Law', 'Second Law', 'Third Law'],
    correctIndex: 1,
  },
];

const TOTAL_LIVES = 5;

function OptionLetter({ letter }: { letter: string }) {
  return (
    <div style={{
      width: 26, height: 26, borderRadius: '50%',
      background: 'var(--nn-bg-page)', display: 'flex', alignItems: 'center',
      justifyContent: 'center', fontSize: 12, fontWeight: 700,
      color: 'var(--nn-text-muted)', flexShrink: 0,
      border: '1px solid var(--nn-border)',
    }}>
      {letter}
    </div>
  );
}

export function QuizPage() {
  const navigate = useNavigate();
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [xp, setXp] = useState(340);
  const [lives] = useState(TOTAL_LIVES);
  const [completedQuestions, setCompletedQuestions] = useState<Set<number>>(new Set());

  const question = QUESTIONS[currentQ];
  const isCorrect = selected === question.correctIndex;

  function handleSelect(idx: number) {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === question.correctIndex) {
      setXp(x => x + 20);
    }
  }

  function handleContinue() {
    setCompletedQuestions(prev => new Set([...prev, currentQ]));
    if (currentQ < QUESTIONS.length - 1) {
      setCurrentQ(q => q + 1);
      setSelected(null);
      setAnswered(false);
    }
  }

  const letters = ['A', 'B', 'C', 'D'];

  return (
    <div className="flex h-screen bg-nn-bg-page text-nn-text-primary overflow-hidden font-['Inter'] transition-colors">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar />

        {/* Page header */}
        <div style={{ padding: '14px 28px', borderBottom: '1px solid var(--nn-border)', background: 'var(--nn-bg-page)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between', transition: 'background 0.3s, border-color 0.3s' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <button
              onClick={() => navigate('/roadmap')}
              className="hover:bg-nn-bg-sidebar transition-colors"
              style={{ background: 'var(--nn-bg-card)', border: '1px solid var(--nn-border)', borderRadius: 9, width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--nn-text-muted)', flexShrink: 0 }}
            >
              <ChevronLeft size={18} />
            </button>
            <div>
              <span style={{ display: 'inline-block', background: 'rgba(124,58,237,0.15)', color: '#A78BFA', border: '1px solid rgba(124,58,237,0.3)', borderRadius: 20, padding: '3px 10px', fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4 }}>
                Practice Module
              </span>
              <h1 style={{ fontSize: 19, fontWeight: 700, color: 'var(--nn-text-primary)', lineHeight: 1.2 }}>Topic Mastery Quiz</h1>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{ display: 'flex', gap: 5 }}>
              {Array.from({ length: TOTAL_LIVES }).map((_, i) => (
                <Heart key={i} size={20} fill={i < lives ? '#EF4444' : 'none'} color={i < lives ? '#EF4444' : 'var(--nn-text-muted)'} strokeWidth={2} />
              ))}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.3)', borderRadius: 20, padding: '5px 12px' }}>
              <Zap size={14} color="#F59E0B" fill="#F59E0B" />
              <span style={{ fontSize: 13, fontWeight: 700, color: '#F59E0B' }}>{xp} XP</span>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          {/* Quiz steps panel */}
          <div style={{ width: 210, background: 'var(--nn-bg-sidebar)', borderRight: '1px solid var(--nn-border)', padding: '20px 14px', flexShrink: 0, overflowY: 'auto', transition: 'background 0.3s, border-color 0.3s' }}>
            <p style={{ fontSize: 10, fontWeight: 700, color: 'var(--nn-text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 14 }}>Quiz Steps</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {QUESTIONS.map((q, idx) => {
                const isActive = idx === currentQ;
                const isDone = completedQuestions.has(idx);
                return (
                  <div
                    key={q.id}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 10,
                      padding: '9px 10px', borderRadius: 10,
                      background: isActive ? 'rgba(59,107,255,0.12)' : 'transparent',
                      border: isActive ? '1px solid rgba(59,107,255,0.25)' : '1px solid transparent',
                    }}
                  >
                    <div style={{
                      width: 24, height: 24, borderRadius: '50%', flexShrink: 0,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      background: isDone ? '#10B981' : isActive ? '#3B6BFF' : 'var(--nn-bg-card)',
                      border: isDone || isActive ? 'none' : '1.5px solid var(--nn-border)',
                      fontSize: 11, fontWeight: 700,
                      color: isDone || isActive ? 'white' : 'var(--nn-text-muted)',
                    }}>
                      {isDone ? <CheckCircle size={13} color="white" strokeWidth={2.5} /> : q.id}
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <p style={{ fontSize: 11, color: isActive ? 'var(--nn-text-primary)' : 'var(--nn-text-muted)', fontWeight: isActive ? 600 : 400, margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Q{q.id} · {q.label}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Question area */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{ flex: 1, padding: '28px 32px', overflowY: 'auto' }}>
              {/* Progress bar */}
              <div style={{ marginBottom: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>Question {currentQ + 1} of {QUESTIONS.length}</span>
                  <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>{Math.round(((completedQuestions.size) / QUESTIONS.length) * 100)}% complete</span>
                </div>
                <div style={{ background: 'var(--nn-border)', borderRadius: 4, height: 4 }}>
                  <div style={{ width: `${(completedQuestions.size / QUESTIONS.length) * 100}%`, height: '100%', background: '#3B6BFF', borderRadius: 4, transition: 'width 0.4s ease' }} />
                </div>
              </div>

              {/* Question card */}
              <div style={{ background: 'var(--nn-bg-card)', border: '1px solid var(--nn-border)', borderRadius: 14, padding: '24px 28px', marginBottom: 16, transition: 'background 0.3s, border-color 0.3s' }}>
                <p style={{ fontSize: 11, color: 'var(--nn-text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>Question {currentQ + 1}</p>
                <p style={{ fontSize: 17, fontWeight: 700, color: 'var(--nn-text-primary)', lineHeight: 1.5, margin: 0 }}>{question.text}</p>
              </div>

              {/* Options */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {question.options.map((option, idx) => {
                  const isSelected = selected === idx;
                  const isCorrectOption = idx === question.correctIndex;
                  const showResult = answered;

                  let borderColor = 'var(--nn-border)';
                  let bgColor = 'var(--nn-bg-card)';
                  let textColor = 'var(--nn-text-primary)';

                  if (showResult && isCorrectOption) {
                    borderColor = '#10B981';
                    bgColor = 'rgba(16,185,129,0.07)';
                  } else if (showResult && isSelected && !isCorrectOption) {
                    borderColor = '#EF4444';
                    bgColor = 'rgba(239,68,68,0.07)';
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelect(idx)}
                      style={{
                        width: '100%', textAlign: 'left', background: bgColor,
                        border: `1.5px solid ${borderColor}`, borderRadius: 12,
                        padding: '14px 16px', cursor: answered ? 'default' : 'pointer',
                        display: 'flex', alignItems: 'center', gap: 12,
                        transition: 'border-color 0.2s, background 0.2s',
                      }}
                      onMouseEnter={(e) => {
                        if (!answered) (e.currentTarget as HTMLButtonElement).style.borderColor = '#3B6BFF';
                      }}
                      onMouseLeave={(e) => {
                        if (!answered) (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--nn-border)';
                      }}
                    >
                      <OptionLetter letter={letters[idx]} />
                      <span style={{ flex: 1, fontSize: 14, color: textColor, lineHeight: 1.4 }}>{option}</span>
                      {showResult && isCorrectOption && (
                        <CheckCircle size={18} color="#10B981" strokeWidth={2.5} style={{ flexShrink: 0 }} />
                      )}
                      {showResult && isSelected && !isCorrectOption && (
                        <div style={{ width: 18, height: 18, borderRadius: '50%', background: '#EF4444', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <span style={{ color: 'white', fontSize: 12, fontWeight: 700, lineHeight: 1 }}>✕</span>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Feedback bar */}
            {answered && (
              <div style={{
                padding: '16px 32px', borderTop: '1px solid var(--nn-border)',
                background: 'var(--nn-bg-card)', display: 'flex', alignItems: 'center',
                justifyContent: 'space-between', flexShrink: 0, transition: 'background 0.3s, border-color 0.3s',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  {isCorrect ? (
                    <>
                      <CheckCircle size={20} color="#10B981" strokeWidth={2.5} />
                      <span style={{ fontSize: 14, color: 'var(--nn-text-primary)' }}>
                        Correct!{'  '}
                        <span style={{ fontWeight: 700, color: '#F59E0B' }}>You gained +20 XP</span>
                      </span>
                    </>
                  ) : (
                    <>
                      <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#EF4444', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <span style={{ color: 'white', fontSize: 13, fontWeight: 700 }}>✕</span>
                      </div>
                      <span style={{ fontSize: 14, color: 'var(--nn-text-primary)' }}>
                        Incorrect.{'  '}
                        <span style={{ color: 'var(--nn-text-muted)' }}>The correct answer is highlighted above.</span>
                      </span>
                    </>
                  )}
                </div>
                <button
                  onClick={handleContinue}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, background: '#3B6BFF', border: 'none', borderRadius: 10, padding: '10px 22px', color: 'white', fontSize: 14, fontWeight: 600, cursor: 'pointer', transition: 'background 0.15s' }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = '#2A57E5'; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = '#3B6BFF'; }}
                >
                  Continue
                  <ArrowRight size={16} strokeWidth={2.5} />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
