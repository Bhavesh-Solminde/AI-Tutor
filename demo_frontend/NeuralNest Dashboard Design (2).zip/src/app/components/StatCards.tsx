import React from 'react';
import { Target, Timer, Flame } from 'lucide-react';

export function StatCards() {
  const radius = 24;
  const circumference = 2 * Math.PI * radius;
  const percentage = 78;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Syllabus Progress */}
      <div className="bg-nn-bg-card border border-nn-border rounded-xl p-5 flex items-center justify-between shadow-sm transition-colors">
        <div>
          <div className="flex items-center gap-2 text-nn-text-muted mb-2">
            <Target size={16} />
            <h3 className="text-sm font-medium">Overall Syllabus</h3>
          </div>
          <div className="text-2xl font-bold text-nn-text-primary">78%</div>
          <p className="text-xs text-[#10B981] mt-1">+5% this week</p>
        </div>
        <div className="relative w-16 h-16 flex items-center justify-center">
          <svg className="w-16 h-16 transform -rotate-90">
            <circle
              cx="32"
              cy="32"
              r={radius}
              stroke="currentColor"
              strokeWidth="6"
              fill="transparent"
              className="text-nn-border transition-colors"
            />
            <circle
              cx="32"
              cy="32"
              r={radius}
              stroke="currentColor"
              strokeWidth="6"
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="text-[#3B6BFF] transition-all duration-1000 ease-out"
            />
          </svg>
          <span className="absolute text-sm font-bold text-nn-text-primary">{percentage}%</span>
        </div>
      </div>

      {/* Exam Countdown */}
      <div className="bg-nn-bg-card border border-nn-border rounded-xl p-5 flex flex-col justify-between relative overflow-hidden shadow-sm transition-colors">
        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
          <Timer size={100} />
        </div>
        <div className="flex items-center gap-2 text-nn-text-muted mb-2 relative z-10">
          <Timer size={16} />
          <h3 className="text-sm font-medium">Exam Countdown</h3>
        </div>
        <div className="relative z-10">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-nn-text-primary">5</span>
            <span className="text-lg font-medium text-nn-text-muted">Days</span>
          </div>
          <div className="text-sm text-nn-text-muted mt-1">Final Physics Exam</div>
        </div>
      </div>

      {/* Weekly Streak */}
      <div className="bg-nn-bg-card border border-nn-border rounded-xl p-5 flex flex-col justify-between shadow-sm transition-colors">
        <div className="flex items-center gap-2 text-nn-text-muted mb-2">
          <Flame size={16} className="text-[#F97316]" />
          <h3 className="text-sm font-medium">Current Streak</h3>
        </div>
        <div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-nn-text-primary">4</span>
            <span className="text-lg font-medium text-nn-text-muted">Days</span>
            <span className="text-2xl ml-1 animate-bounce">🔥</span>
          </div>
          <p className="text-sm text-nn-text-muted mt-1">Keep it up! 3 days to week goal.</p>
        </div>
      </div>
    </div>
  );
}