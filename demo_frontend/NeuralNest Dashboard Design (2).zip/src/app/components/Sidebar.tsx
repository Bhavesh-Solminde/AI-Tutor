import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Brain, LayoutDashboard, Map, Bot, GraduationCap,
  ListChecks, MessageSquare, ChevronDown, ChevronRight,
  FileText, Plus
} from 'lucide-react';

const navItems = [
  { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
  { name: 'Roadmap', icon: Map, path: '/roadmap' },
  { name: 'AI Tutor', icon: Bot, path: '/ai-tutor' },
  { name: 'Exam Mode', icon: GraduationCap, path: '/exam-mode' },
  { name: 'Active Quizzes', icon: ListChecks, path: '/quiz' },
];

export function Sidebar() {
  const [chatOpen, setChatOpen] = useState(true);
  const [notesOpen, setNotesOpen] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <aside className="w-[210px] bg-nn-bg-sidebar border-r border-nn-border flex flex-col h-full shrink-0 transition-colors">
      <div className="p-5 flex items-center gap-3 border-b border-nn-border">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#3B6BFF] to-[#244bd9] flex items-center justify-center shadow-[0_0_15px_rgba(59,107,255,0.3)]">
          <Brain size={18} className="text-white" />
        </div>
        <span className="font-bold text-[15px] tracking-wide text-nn-text-primary">NeuralNest</span>
      </div>

      <div className="flex-1 overflow-y-auto py-5 px-3 space-y-6 scrollbar-hide">
        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <button
                key={item.name}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-[#3B6BFF]/10 text-[#3B6BFF] dark:text-[#3B6BFF]'
                    : 'text-nn-text-muted hover:bg-nn-bg-card hover:text-nn-text-primary'
                }`}
              >
                <item.icon size={18} className={isActive ? 'text-[#3B6BFF]' : 'text-nn-text-muted'} />
                {item.name}
              </button>
            );
          })}
        </nav>

        <div className="space-y-1">
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className="w-full flex items-center justify-between px-3 py-2 text-xs font-semibold text-nn-text-muted uppercase tracking-wider hover:text-nn-text-primary transition-colors"
          >
            <span>Chat History</span>
            {chatOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </button>
          {chatOpen && (
            <div className="space-y-1 mt-1">
              {['Exam Pacing Plan', 'Roadmap Adjustments', 'Other Queries'].map((chat) => (
                <button key={chat} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-nn-text-muted hover:bg-nn-bg-card hover:text-nn-text-primary transition-colors">
                  <MessageSquare size={16} />
                  <span className="truncate">{chat}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-1">
          <button
            onClick={() => setNotesOpen(!notesOpen)}
            className="w-full flex items-center justify-between px-3 py-2 text-xs font-semibold text-nn-text-muted uppercase tracking-wider hover:text-nn-text-primary transition-colors"
          >
            <span>Notes</span>
            {notesOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </button>
          {notesOpen && (
            <div className="space-y-1 mt-1">
              {['Ch1_Kinetics.pdf', 'Ch2_Equilibrium.pdf', 'Mock_Exam_3.pdf'].map((note) => (
                <button key={note} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-nn-text-muted hover:bg-nn-bg-card hover:text-nn-text-primary transition-colors">
                  <FileText size={16} />
                  <span className="truncate">{note}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="p-4 border-t border-nn-border">
        <button className="w-full flex items-center justify-center gap-2 bg-[#3B6BFF] hover:bg-[#2A57E5] text-white py-2.5 rounded-xl text-sm font-semibold transition-all shadow-[0_1px_3px_rgba(0,0,0,0.08)] dark:shadow-[0_4px_14px_rgba(59,107,255,0.25)] hover:shadow-md dark:hover:shadow-[0_6px_20px_rgba(59,107,255,0.4)]">
          <Plus size={18} />
          New Session
        </button>
      </div>
    </aside>
  );
}