import React from 'react';
import { Sparkles, PlayCircle, BookOpen, Clock, Calendar, CheckCircle2 } from 'lucide-react';

export function BottomSection() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left: AI Recommendation */}
      <div className="bg-nn-bg-card border border-nn-border rounded-xl p-6 flex flex-col justify-between shadow-sm transition-colors">
        <div>
          <div className="flex items-center gap-2 text-[#3B6BFF] mb-4">
            <Sparkles size={18} />
            <h2 className="text-sm font-bold uppercase tracking-wider">AI Recommended Next Step</h2>
          </div>
          <h3 className="text-xl font-bold text-nn-text-primary mb-2">Wave-Particle Duality</h3>
          <p className="text-nn-text-muted text-sm mb-6 leading-relaxed">
            You scored 15% on the last pop quiz for this topic. The AI suggests reviewing the core concepts before moving on to advanced quantum mechanics.
          </p>

          <div className="bg-nn-bg-page border border-nn-border rounded-lg p-4 mb-6 transition-colors">
            <h4 className="text-xs font-semibold text-nn-text-muted uppercase tracking-wider mb-3">Continue where you left off</h4>
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#3B6BFF]/10 flex items-center justify-center shrink-0">
                <BookOpen size={20} className="text-[#3B6BFF]" />
              </div>
              <div className="flex-1 min-w-0">
                <h5 className="text-sm font-medium text-nn-text-primary truncate">Ch. 5: De Broglie Wavelength</h5>
                <div className="flex items-center gap-4 mt-1 text-xs text-nn-text-muted">
                  <span className="flex items-center gap-1"><Clock size={12} /> 12 mins left</span>
                  <span>Page 42/50</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <button className="w-full flex items-center justify-center gap-2 bg-[#3B6BFF] hover:bg-[#2A57E5] text-white py-3 rounded-xl text-sm font-bold transition-all shadow-[0_1px_3px_rgba(0,0,0,0.08)] dark:shadow-[0_4px_14px_rgba(59,107,255,0.25)] hover:shadow-md dark:hover:shadow-[0_6px_20px_rgba(59,107,255,0.4)]">
          <PlayCircle size={18} />
          Resume Study Pacing
        </button>
      </div>

      {/* Right: Exam Rescue Timeline */}
      <div className="bg-nn-bg-card border border-nn-border rounded-xl p-6 shadow-sm transition-colors">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-nn-text-primary">Exam Rescue Timeline</h2>
          <div className="px-3 py-1 rounded-full bg-[#EF4444]/10 text-[#EF4444] text-xs font-bold border border-[#EF4444]/20">
            Intense Mode
          </div>
        </div>

        <div className="relative pl-4 space-y-6 before:absolute before:inset-y-0 before:left-[21px] before:w-[2px] before:bg-nn-border">
          {/* Day 1 - Past */}
          <div className="relative flex items-start gap-4">
            <div className="absolute -left-1 w-6 h-6 rounded-full bg-[#10B981] ring-4 ring-nn-bg-card flex items-center justify-center z-10 transition-colors">
              <CheckCircle2 size={14} className="text-white" />
            </div>
            <div className="ml-8 pt-0.5">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-bold text-nn-text-primary">Day 1</span>
                <span className="text-xs text-nn-text-muted">Yesterday</span>
              </div>
              <p className="text-sm text-nn-text-muted">Mastered Thermodynamics & Kinematics</p>
            </div>
          </div>

          {/* Day 2 - Today */}
          <div className="relative flex items-start gap-4">
            <div className="absolute -left-1 w-6 h-6 rounded-full bg-[#3B6BFF] ring-4 ring-nn-bg-card flex items-center justify-center z-10 shadow-[0_0_10px_rgba(59,107,255,0.5)] transition-colors">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
            </div>
            <div className="ml-8 pt-0.5">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-bold text-[#3B6BFF]">Day 2 (Today)</span>
                <span className="text-xs text-[#3B6BFF]/70 bg-[#3B6BFF]/10 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">In Progress</span>
              </div>
              <div className="bg-nn-bg-page border border-nn-border rounded-lg p-3 mt-2 transition-colors">
                <p className="text-sm text-nn-text-primary font-medium mb-1">Quantum Mechanics Focus</p>
                <div className="flex items-center justify-between text-xs text-nn-text-muted">
                  <span>2/4 topics completed</span>
                  <span>50%</span>
                </div>
                <div className="w-full h-1.5 bg-nn-border rounded-full mt-2 overflow-hidden transition-colors">
                  <div className="w-1/2 h-full bg-[#3B6BFF] rounded-full"></div>
                </div>
              </div>
            </div>
          </div>

          {/* Day 3 - Future */}
          <div className="relative flex items-start gap-4">
            <div className="absolute -left-1 w-6 h-6 rounded-full bg-nn-border ring-4 ring-nn-bg-card flex items-center justify-center z-10 transition-colors">
              <Calendar size={12} className="text-nn-text-muted" />
            </div>
            <div className="ml-8 pt-0.5 opacity-60">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-bold text-nn-text-primary">Day 3</span>
                <span className="text-xs text-nn-text-muted">Tomorrow</span>
              </div>
              <p className="text-sm text-nn-text-muted">Electromagnetism Deep Dive</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}