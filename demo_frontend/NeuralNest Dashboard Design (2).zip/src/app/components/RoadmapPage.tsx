import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Sparkles, Lock, X, Clock, BarChart2, Target, ZoomIn, ZoomOut, Home } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';

type NodeState = 'mastered' | 'active' | 'locked';

interface NodeData {
  id: string;
  label: string;
  state: NodeState;
  estimatedTime: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  mastery: number;
  x: number;
  y: number;
}

interface Edge {
  from: string;
  to: string;
}

const NODES: NodeData[] = [
  { id: 'classical', label: 'Classical Mechanics', state: 'mastered', estimatedTime: '8 hrs', difficulty: 'Medium', mastery: 100, x: 400, y: 60 },
  { id: 'kinematics', label: 'Kinematics', state: 'mastered', estimatedTime: '4 hrs', difficulty: 'Easy', mastery: 100, x: 200, y: 180 },
  { id: 'dynamics', label: 'Dynamics', state: 'mastered', estimatedTime: '5 hrs', difficulty: 'Medium', mastery: 92, x: 400, y: 180 },
  { id: 'thermo', label: 'Thermodynamics', state: 'mastered', estimatedTime: '6 hrs', difficulty: 'Medium', mastery: 88, x: 620, y: 180 },
  { id: 'waves', label: 'Waves & Oscillations', state: 'active', estimatedTime: '5 hrs', difficulty: 'Medium', mastery: 61, x: 200, y: 310 },
  { id: 'work', label: 'Work & Energy', state: 'active', estimatedTime: '3 hrs', difficulty: 'Easy', mastery: 74, x: 400, y: 310 },
  { id: 'kinetic', label: 'Kinetic Theory', state: 'active', estimatedTime: '4 hrs', difficulty: 'Medium', mastery: 45, x: 620, y: 310 },
  { id: 'sound', label: 'Sound', state: 'locked', estimatedTime: '3 hrs', difficulty: 'Easy', mastery: 0, x: 100, y: 430 },
  { id: 'optics', label: 'Optics', state: 'locked', estimatedTime: '4 hrs', difficulty: 'Medium', mastery: 0, x: 280, y: 430 },
  { id: 'momentum', label: 'Momentum', state: 'locked', estimatedTime: '3 hrs', difficulty: 'Medium', mastery: 0, x: 460, y: 430 },
  { id: 'laws-thermo', label: 'Laws of Thermo', state: 'locked', estimatedTime: '5 hrs', difficulty: 'Hard', mastery: 0, x: 640, y: 430 },
  { id: 'rotation', label: 'Rotational Motion', state: 'locked', estimatedTime: '4 hrs', difficulty: 'Hard', mastery: 0, x: 460, y: 550 },
  { id: 'electricity', label: 'Electricity', state: 'locked', estimatedTime: '6 hrs', difficulty: 'Hard', mastery: 0, x: 820, y: 180 },
  { id: 'magnetism', label: 'Magnetism', state: 'locked', estimatedTime: '5 hrs', difficulty: 'Hard', mastery: 0, x: 820, y: 310 },
  { id: 'em-waves', label: 'Electromagnetic Waves', state: 'locked', estimatedTime: '4 hrs', difficulty: 'Hard', mastery: 0, x: 820, y: 430 },
  { id: 'modern', label: 'Modern Physics', state: 'locked', estimatedTime: '7 hrs', difficulty: 'Hard', mastery: 0, x: 640, y: 550 },
];

const EDGES: Edge[] = [
  { from: 'classical', to: 'kinematics' },
  { from: 'classical', to: 'dynamics' },
  { from: 'classical', to: 'thermo' },
  { from: 'kinematics', to: 'waves' },
  { from: 'dynamics', to: 'work' },
  { from: 'thermo', to: 'kinetic' },
  { from: 'waves', to: 'sound' },
  { from: 'waves', to: 'optics' },
  { from: 'work', to: 'momentum' },
  { from: 'kinetic', to: 'laws-thermo' },
  { from: 'momentum', to: 'rotation' },
  { from: 'thermo', to: 'electricity' },
  { from: 'electricity', to: 'magnetism' },
  { from: 'magnetism', to: 'em-waves' },
  { from: 'laws-thermo', to: 'modern' },
  { from: 'em-waves', to: 'modern' },
  { from: 'rotation', to: 'modern' },
];

const NODE_RADIUS = 28;

function nodeCenter(node: NodeData) {
  return { x: node.x + NODE_RADIUS, y: node.y + NODE_RADIUS };
}

function edgeColor(fromState: NodeState, toState: NodeState) {
  if (fromState === 'mastered' && toState === 'mastered') return '#10B981';
  if (fromState === 'mastered' && toState === 'active') return '#F59E0B';
  return 'var(--nn-border)';
}

function difficultyColor(d: string) {
  if (d === 'Easy') return '#10B981';
  if (d === 'Medium') return '#F59E0B';
  return '#EF4444';
}

function NodeCircle({ node, onClick }: { node: NodeData; onClick: (node: NodeData, e: React.MouseEvent) => void }) {
  const baseStyle: React.CSSProperties = {
    position: 'absolute',
    left: node.x,
    top: node.y,
    width: NODE_RADIUS * 2,
    height: NODE_RADIUS * 2,
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'transform 0.15s ease',
    userSelect: 'none',
  };

  let circleStyle: React.CSSProperties = {};
  if (node.state === 'mastered') {
    circleStyle = {
      background: '#10B981',
      boxShadow: '0 0 0 3px rgba(16,185,129,0.2), 0 0 16px rgba(16,185,129,0.3)',
    };
  } else if (node.state === 'active') {
    circleStyle = {
      background: '#F59E0B',
      boxShadow: '0 0 0 3px rgba(245,158,11,0.25), 0 0 20px rgba(245,158,11,0.5)',
      animation: 'pulseGlow 2s ease-in-out infinite',
    };
  } else {
    circleStyle = {
      background: 'var(--nn-bg-card)',
      border: '2px solid var(--nn-border)',
    };
  }

  return (
    <div style={{ position: 'absolute', left: node.x - 50 + NODE_RADIUS, top: node.y + NODE_RADIUS * 2 + 6, width: 100, textAlign: 'center', pointerEvents: 'none' }}>
      <div
        style={{ ...baseStyle, left: 50 - NODE_RADIUS, top: -(NODE_RADIUS * 2 + 6), ...circleStyle }}
        onClick={(e) => onClick(node, e)}
        onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.transform = 'scale(1.12)'; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.transform = 'scale(1)'; }}
      >
        {node.state === 'mastered' && <Check size={16} color="white" strokeWidth={3} />}
        {node.state === 'active' && <Sparkles size={16} color="white" strokeWidth={2} />}
        {node.state === 'locked' && <Lock size={14} color="var(--nn-text-muted)" strokeWidth={2} />}
      </div>
      <span style={{ fontSize: 11, color: 'var(--nn-text-muted)', lineHeight: 1.3, display: 'block', marginTop: 2 }}>{node.label}</span>
    </div>
  );
}

interface PopupCardProps {
  node: NodeData;
  worldX: number;
  worldY: number;
  onClose: () => void;
  onStartLearning: () => void;
}

function PopupCard({ node, worldX, worldY, onClose, onStartLearning }: PopupCardProps) {
  const stateLabel = node.state === 'mastered' ? 'Mastered' : node.state === 'active' ? 'In Progress' : 'Locked';
  const stateColor = node.state === 'mastered' ? '#10B981' : node.state === 'active' ? '#F59E0B' : '#6B7280';
  const stateBg = node.state === 'mastered' ? 'rgba(16,185,129,0.12)' : node.state === 'active' ? 'rgba(245,158,11,0.12)' : 'rgba(107,114,128,0.12)';

  return (
    <div
      style={{
        position: 'absolute',
        left: worldX,
        top: worldY,
        width: 240,
        background: 'var(--nn-bg-card)',
        border: '1px solid var(--nn-border)',
        borderRadius: 14,
        padding: 18,
        zIndex: 100,
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        pointerEvents: 'all',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
        <span style={{ color: 'var(--nn-text-primary)', fontWeight: 700, fontSize: 14, lineHeight: 1.3, flex: 1, paddingRight: 8 }}>{node.label}</span>
        <button
          onClick={onClose}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--nn-text-muted)', padding: 2, flexShrink: 0 }}
        >
          <X size={15} />
        </button>
      </div>

      <span style={{ display: 'inline-block', background: stateBg, color: stateColor, border: `1px solid ${stateColor}40`, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600, marginBottom: 14 }}>
        {stateLabel}
      </span>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Clock size={13} color="var(--nn-text-muted)" />
          <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>Estimated: <span style={{ color: 'var(--nn-text-primary)' }}>{node.estimatedTime}</span></span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <BarChart2 size={13} color="var(--nn-text-muted)" />
          <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>Difficulty: <span style={{ color: difficultyColor(node.difficulty) }}>{node.difficulty}</span></span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Target size={13} color="var(--nn-text-muted)" />
            <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>Mastery: <span style={{ color: 'var(--nn-text-primary)' }}>{node.mastery}%</span></span>
          </div>
          <div style={{ background: 'var(--nn-border)', borderRadius: 4, height: 5, overflow: 'hidden', marginLeft: 21 }}>
            <div style={{ width: `${node.mastery}%`, height: '100%', background: node.mastery === 100 ? '#10B981' : '#3B6BFF', borderRadius: 4, transition: 'width 0.4s ease' }} />
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <button
          onClick={onStartLearning}
          style={{ width: '100%', background: '#3B6BFF', border: 'none', borderRadius: 10, padding: '9px 0', color: 'white', fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'background 0.15s' }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = '#2A57E5'; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = '#3B6BFF'; }}
        >
          Start Learning
        </button>
        <button
          style={{ width: '100%', background: 'transparent', border: '1.5px solid #3B6BFF', borderRadius: 10, padding: '9px 0', color: '#3B6BFF', fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'background 0.15s' }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(59,107,255,0.08)'; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
        >
          Test my Skills
        </button>
      </div>
    </div>
  );
}

export function RoadmapPage() {
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(0.85);
  const [pan, setPan] = useState({ x: 40, y: 20 });
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [selectedNode, setSelectedNode] = useState<NodeData | null>(null);
  const [popupPos, setPopupPos] = useState({ x: 0, y: 0 });
  const dragThreshold = useRef(false);

  const nodeMap = Object.fromEntries(NODES.map(n => [n.id, n]));

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.08 : 0.08;
    setZoom(z => Math.min(2.0, Math.max(0.3, z + delta)));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setDragging(true);
    dragThreshold.current = false;
    setDragStart({ x: e.clientX, y: e.clientY });
    setPanStart({ ...pan });
  }, [pan]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!dragging) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragThreshold.current = true;
    setPan({ x: panStart.x + dx, y: panStart.y + dy });
  }, [dragging, dragStart, panStart]);

  const handleMouseUp = useCallback(() => {
    setDragging(false);
  }, []);

  const handleNodeClick = useCallback((node: NodeData, e: React.MouseEvent) => {
    e.stopPropagation();
    if (dragThreshold.current) return;
    const center = nodeCenter(node);
    setPopupPos({ x: center.x + 36, y: center.y - 20 });
    setSelectedNode(node);
  }, []);

  const handleCanvasClick = useCallback(() => {
    setSelectedNode(null);
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedNode(null);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const worldWidth = 980;
  const worldHeight = 700;

  return (
    <div className="flex h-screen bg-nn-bg-page text-nn-text-primary overflow-hidden font-['Inter'] transition-colors">
      <style>{`
        @keyframes pulseGlow {
          0%, 100% { box-shadow: 0 0 0 3px rgba(245,158,11,0.25), 0 0 20px rgba(245,158,11,0.5); }
          50% { box-shadow: 0 0 0 6px rgba(245,158,11,0.15), 0 0 32px rgba(245,158,11,0.7); }
        }
      `}</style>
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar />
        <div style={{ padding: '16px 24px 8px', borderBottom: '1px solid var(--nn-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--nn-bg-page)', flexShrink: 0 }}>
          <div>
            <p style={{ fontSize: 11, color: 'var(--nn-text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 2 }}>Learning Path</p>
            <h1 style={{ fontSize: 20, fontWeight: 700, color: 'var(--nn-text-primary)' }}>Physics Roadmap</h1>
          </div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 12 }}>
              {[
                { color: '#10B981', label: 'Mastered' },
                { color: '#F59E0B', label: 'In Progress' },
                { color: 'var(--nn-border)', label: 'Locked', border: '2px solid var(--nn-text-muted)' },
              ].map(({ color, label, border }) => (
                <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 12, height: 12, borderRadius: '50%', background: color, border }} />
                  <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div
          ref={containerRef}
          style={{ flex: 1, position: 'relative', overflow: 'hidden', cursor: dragging ? 'grabbing' : 'grab', background: 'var(--nn-bg-page)' }}
          onWheel={handleWheel}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onClick={handleCanvasClick}
        >
          {/* dot grid background */}
          <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
            <defs>
              <pattern id="dots" x={pan.x % (20 * zoom)} y={pan.y % (20 * zoom)} width={20 * zoom} height={20 * zoom} patternUnits="userSpaceOnUse">
                <circle cx={1} cy={1} r={1} fill="var(--nn-border)" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#dots)" />
          </svg>

          <div
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              transformOrigin: '0 0',
              transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
              width: worldWidth,
              height: worldHeight,
            }}
          >
            {/* SVG edges */}
            <svg
              style={{ position: 'absolute', top: 0, left: 0, width: worldWidth, height: worldHeight, overflow: 'visible', pointerEvents: 'none' }}
            >
              <defs>
                <marker id="arrow-green" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                  <path d="M0,0 L0,6 L8,3 z" fill="#10B981" />
                </marker>
                <marker id="arrow-amber" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                  <path d="M0,0 L0,6 L8,3 z" fill="#F59E0B" />
                </marker>
                <marker id="arrow-gray" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                  <path d="M0,0 L0,6 L8,3 z" fill="var(--nn-border)" />
                </marker>
              </defs>
              {EDGES.map((edge) => {
                const fromNode = nodeMap[edge.from];
                const toNode = nodeMap[edge.to];
                if (!fromNode || !toNode) return null;
                const fc = nodeCenter(fromNode);
                const tc = nodeCenter(toNode);
                const dx = tc.x - fc.x;
                const dy = tc.y - fc.y;
                const len = Math.sqrt(dx * dx + dy * dy);
                const ux = dx / len;
                const uy = dy / len;
                const sx = fc.x + ux * NODE_RADIUS;
                const sy = fc.y + uy * NODE_RADIUS;
                const ex = tc.x - ux * (NODE_RADIUS + 7);
                const ey = tc.y - uy * (NODE_RADIUS + 7);
                const mx = (sx + ex) / 2 - uy * 20;
                const my = (sy + ey) / 2 + ux * 20;
                const color = edgeColor(fromNode.state, toNode.state);
                const markerId = color === '#10B981' ? 'arrow-green' : color === '#F59E0B' ? 'arrow-amber' : 'arrow-gray';
                return (
                  <path
                    key={`${edge.from}-${edge.to}`}
                    d={`M ${sx} ${sy} Q ${mx} ${my} ${ex} ${ey}`}
                    stroke={color}
                    strokeWidth={2}
                    fill="none"
                    opacity={color === 'var(--nn-border)' ? 0.6 : 0.85}
                    markerEnd={`url(#${markerId})`}
                  />
                );
              })}
            </svg>

            {/* Nodes */}
            {NODES.map(node => (
              <NodeCircle key={node.id} node={node} onClick={handleNodeClick} />
            ))}

            {/* Popup */}
            {selectedNode && (
              <PopupCard
                node={selectedNode}
                worldX={popupPos.x}
                worldY={popupPos.y}
                onClose={() => setSelectedNode(null)}
                onStartLearning={() => navigate('/quiz')}
              />
            )}
          </div>

          {/* Zoom controls */}
          <div style={{ position: 'absolute', bottom: 24, right: 24, display: 'flex', flexDirection: 'column', gap: 6, zIndex: 50 }}>
            {[
              { icon: ZoomIn, action: () => setZoom(z => Math.min(2.0, z + 0.15)), title: 'Zoom in' },
              { icon: ZoomOut, action: () => setZoom(z => Math.max(0.3, z - 0.15)), title: 'Zoom out' },
              { icon: Home, action: () => { setZoom(0.85); setPan({ x: 40, y: 20 }); }, title: 'Reset view' },
            ].map(({ icon: Icon, action, title }) => (
              <button
                key={title}
                title={title}
                onClick={(e) => { e.stopPropagation(); action(); }}
                style={{ width: 36, height: 36, background: '#1E1E2C', border: '1px solid #2A2A3E', borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#9CA3AF', transition: 'background 0.15s, color 0.15s' }}
                onMouseEnter={(e) => { const b = e.currentTarget as HTMLButtonElement; b.style.background = '#2A2A3E'; b.style.color = 'white'; }}
                onMouseLeave={(e) => { const b = e.currentTarget as HTMLButtonElement; b.style.background = '#1E1E2C'; b.style.color = '#9CA3AF'; }}
              >
                <Icon size={16} />
              </button>
            ))}
          </div>

          {/* Zoom level indicator */}
          <div style={{ position: 'absolute', bottom: 24, left: 24, background: '#1E1E2C', border: '1px solid #2A2A3E', borderRadius: 8, padding: '4px 10px', fontSize: 12, color: '#6B7280', zIndex: 50 }}>
            {Math.round(zoom * 100)}%
          </div>
        </div>
      </div>
    </div>
  );
}
