import React from 'react';
import { StatCards } from './StatCards';
import { TopicsTable } from './TopicsTable';
import { BottomSection } from './BottomSection';

export function DashboardContent() {
  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-nn-text-primary">Welcome back, Sarah! 👋</h1>
          <p className="text-nn-text-muted text-sm mt-1">Let's continue your exam preparation journey.</p>
        </div>
      </div>
      
      <StatCards />
      <TopicsTable />
      <BottomSection />
    </div>
  );
}