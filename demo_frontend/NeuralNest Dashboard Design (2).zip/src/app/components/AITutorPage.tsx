import React, { useState, useRef, useEffect } from 'react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { Brain, FileText, Calculator, Layers, Globe, Paperclip, MessageSquare, Mic, ArrowUp } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string;
}

export function AITutorPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const handleSend = () => {
    if (!inputValue.trim()) return;
    
    const newUserMsg: Message = { id: Date.now().toString(), role: 'user', content: inputValue };
    setMessages(prev => [...prev, newUserMsg]);
    setInputValue('');

    // Mock AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: 'ai',
        content: "I'd be happy to help with that! Let's break it down step-by-step. First, we need to understand the core concepts. Would you like me to explain the basic theory or jump straight into some examples?"
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 600);
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex h-screen bg-nn-bg-page text-nn-text-primary overflow-hidden font-['Inter'] selection:bg-[#3B6BFF] selection:text-white transition-colors">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 h-screen">
        <TopBar />
        
        {/* Main Content Area */}
        <main className="flex-1 flex flex-col relative overflow-hidden">
          
          {/* Scrollable Chat Area */}
          <div className="flex-1 overflow-y-auto w-full flex flex-col scrollbar-hide">
            {messages.length === 0 ? (
              // Empty State
              <div className="flex-1 flex flex-col items-center justify-center p-6 w-full max-w-3xl mx-auto min-h-full">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#3B6BFF] to-[#244bd9] flex items-center justify-center shadow-[0_0_20px_rgba(59,107,255,0.3)] mb-6">
                  <Brain size={28} className="text-white" />
                </div>
                
                <h1 className="text-2xl font-bold text-nn-text-primary mb-8">Hello, I'm NeuralNest</h1>
                
                <div className="grid grid-cols-2 gap-4 w-full max-w-2xl mb-8">
                  {/* Suggestion Cards */}
                  <SuggestionCard 
                    icon={FileText} 
                    text="Explain my lecture notes" 
                    onClick={() => setInputValue("Explain my lecture notes")} 
                  />
                  <SuggestionCard 
                    icon={Calculator} 
                    text="Test my multiplication tables" 
                    onClick={() => setInputValue("Test my multiplication tables")} 
                  />
                  <SuggestionCard 
                    icon={Layers} 
                    text="Create math formula flashcards" 
                    onClick={() => setInputValue("Create math formula flashcards")} 
                  />
                  <SuggestionCard 
                    icon={Globe} 
                    text="Make a review sheet for Spanish" 
                    onClick={() => setInputValue("Make a review sheet for Spanish")} 
                  />
                </div>
                
                <p className="text-[13px] text-nn-text-muted font-medium">View More • View Previous Chat Sessions</p>
              </div>
            ) : (
              // Active Chat State
              <div className="w-full max-w-3xl mx-auto p-6 pb-32 flex flex-col gap-6">
                {messages.map((msg, index) => {
                  const isLastAi = msg.role === 'ai' && index === messages.length - 1;
                  return (
                    <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                      <div 
                        className={`max-w-[85%] px-5 py-4 text-[15px] leading-relaxed shadow-sm transition-colors ${
                          msg.role === 'user' 
                            ? 'bg-[#3B6BFF] text-white rounded-2xl rounded-tr-sm' 
                            : 'bg-nn-bg-card border border-nn-border text-nn-text-primary rounded-2xl rounded-tl-sm'
                        }`}
                      >
                        {msg.content}
                      </div>
                      
                      {isLastAi && (
                        <div className="mt-4 flex flex-col items-start gap-3 w-full">
                          <div className="flex flex-wrap gap-2">
                            <button className="px-4 py-1.5 rounded-full border border-[#3B6BFF] text-[#3B6BFF] hover:bg-[#3B6BFF]/10 text-sm font-medium transition-colors">Understood</button>
                            <button className="px-4 py-1.5 rounded-full border border-[#3B6BFF] text-[#3B6BFF] hover:bg-[#3B6BFF]/10 text-sm font-medium transition-colors">Need more help</button>
                            <button className="px-4 py-1.5 rounded-full border border-[#3B6BFF] text-[#3B6BFF] hover:bg-[#3B6BFF]/10 text-sm font-medium transition-colors">Go deeper</button>
                          </div>
                          <p className="text-sm italic text-nn-text-muted pl-1 mt-1">Do you have any doubts or questions before we move on?</p>
                        </div>
                      )}
                    </div>
                  );
                })}
                <div ref={chatEndRef} />
              </div>
            )}
          </div>

          {/* Input Bar */}
          <div className="w-full bg-nn-bg-card border-t border-nn-border p-4 transition-colors">
            <div className="max-w-3xl mx-auto w-full flex flex-col gap-3 relative z-10">
              <div className="flex items-center gap-3 bg-nn-bg-page border border-nn-border rounded-2xl px-3 py-2 shadow-sm transition-colors">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSend();
                  }}
                  placeholder="Ask your AI tutor anything..."
                  className="flex-1 bg-transparent text-nn-text-primary placeholder-nn-text-muted outline-none text-[15px] px-2 py-1"
                />
                <button 
                  onClick={handleSend}
                  disabled={!inputValue.trim()}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shrink-0 ${
                    inputValue.trim() 
                      ? 'bg-[#3B6BFF] hover:bg-[#2A57E5] shadow-[0_2px_8px_rgba(59,107,255,0.4)] text-white' 
                      : 'bg-nn-border text-nn-text-muted'
                  }`}
                >
                  <ArrowUp size={18} strokeWidth={2.5} />
                </button>
              </div>
              
              <div className="flex items-center justify-between px-2">
                <div className="flex items-center gap-4 text-nn-text-muted">
                  <button className="hover:text-nn-text-primary transition-colors">
                    <Paperclip size={18} />
                  </button>
                  <button className="hover:text-nn-text-primary transition-colors">
                    <Globe size={18} />
                  </button>
                  <button className="hover:text-nn-text-primary transition-colors">
                    <MessageSquare size={18} />
                  </button>
                  <div className="px-3 py-1 bg-nn-bg-page rounded-full text-xs font-medium border border-nn-border text-nn-text-muted transition-colors">
                    0 materials
                  </div>
                </div>
                <button className="text-nn-text-muted hover:text-nn-text-primary transition-colors">
                  <Mic size={18} />
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function SuggestionCard({ icon: Icon, text, onClick }: { icon: any, text: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="flex flex-col items-start gap-3 p-4 bg-nn-bg-card border border-nn-border hover:border-[#3B6BFF]/50 rounded-xl transition-all text-left hover:bg-nn-bg-page shadow-sm"
      style={{ borderRadius: '12px' }}
    >
      <div className="text-[#3B6BFF]">
        <Icon size={20} />
      </div>
      <span className="text-[14px] text-nn-text-primary font-medium leading-snug">{text}</span>
    </button>
  );
}
