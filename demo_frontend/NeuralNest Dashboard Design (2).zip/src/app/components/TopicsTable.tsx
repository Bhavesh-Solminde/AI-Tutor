import React, { useState } from 'react';
import { Play, ArrowUpDown, CheckCircle2 } from 'lucide-react';

type Difficulty = 'Easy' | 'Medium' | 'Hard';

interface Topic {
  id: string;
  name: string;
  difficulty: Difficulty;
  timeEstimate: string;
  mastery: number;
  subject: string;
}

const initialTopics: Topic[] = [
  { id: '1', name: 'Quantum Mechanics Basics', subject: 'Physics', difficulty: 'Hard', timeEstimate: '45 mins', mastery: 30 },
  { id: '2', name: 'Electromagnetism Review', subject: 'Physics', difficulty: 'Medium', timeEstimate: '30 mins', mastery: 85 },
  { id: '3', name: 'Thermodynamics Laws', subject: 'Physics', difficulty: 'Medium', timeEstimate: '60 mins', mastery: 100 },
  { id: '4', name: 'Kinematics Formulas', subject: 'Physics', difficulty: 'Easy', timeEstimate: '20 mins', mastery: 95 },
  { id: '5', name: 'Wave-Particle Duality', subject: 'Physics', difficulty: 'Hard', timeEstimate: '50 mins', mastery: 15 },
];

const difficultyConfig = {
  Easy: 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20',
  Medium: 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20',
  Hard: 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/20',
};

export function TopicsTable() {
  const [sortField, setSortField] = useState<keyof Topic>('mastery');
  const [sortAsc, setSortAsc] = useState(true);

  const sortedTopics = [...initialTopics].sort((a, b) => {
    let aVal = a[sortField];
    let bVal = b[sortField];

    if (sortField === 'difficulty') {
      const rank = { Easy: 1, Medium: 2, Hard: 3 };
      aVal = rank[a.difficulty];
      bVal = rank[b.difficulty];
    }

    if (aVal < bVal) return sortAsc ? -1 : 1;
    if (aVal > bVal) return sortAsc ? 1 : -1;
    return 0;
  });

  const toggleSort = (field: keyof Topic) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="bg-nn-bg-card border border-nn-border rounded-xl overflow-hidden shadow-sm transition-colors">
      <div className="p-5 border-b border-nn-border flex items-center justify-between">
        <h2 className="text-lg font-semibold text-nn-text-primary">Upcoming Topics</h2>
        <button className="text-sm text-[#3B6BFF] hover:text-[#2A57E5] font-medium transition-colors">
          View All
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-nn-text-primary">
          <thead className="bg-nn-bg-sidebar/50 text-nn-text-muted border-b border-nn-border transition-colors">
            <tr>
              <th className="px-5 py-4 font-medium">
                <button onClick={() => toggleSort('name')} className="flex items-center gap-2 hover:text-nn-text-primary transition-colors">
                  Topic Name <ArrowUpDown size={14} />
                </button>
              </th>
              <th className="px-5 py-4 font-medium">
                <button onClick={() => toggleSort('difficulty')} className="flex items-center gap-2 hover:text-nn-text-primary transition-colors">
                  Difficulty <ArrowUpDown size={14} />
                </button>
              </th>
              <th className="px-5 py-4 font-medium">
                <button onClick={() => toggleSort('timeEstimate')} className="flex items-center gap-2 hover:text-nn-text-primary transition-colors">
                  Est. Time <ArrowUpDown size={14} />
                </button>
              </th>
              <th className="px-5 py-4 font-medium w-48">
                <button onClick={() => toggleSort('mastery')} className="flex items-center gap-2 hover:text-nn-text-primary transition-colors">
                  Mastery <ArrowUpDown size={14} />
                </button>
              </th>
              <th className="px-5 py-4 font-medium text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-nn-border">
            {sortedTopics.map((topic) => (
              <tr key={topic.id} className="hover:bg-nn-bg-sidebar transition-colors group">
                <td className="px-5 py-4">
                  <div className="font-medium text-nn-text-primary">{topic.name}</div>
                  <div className="text-xs text-nn-text-muted mt-0.5">{topic.subject}</div>
                </td>
                <td className="px-5 py-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${difficultyConfig[topic.difficulty]}`}>
                    {topic.difficulty}
                  </span>
                </td>
                <td className="px-5 py-4 text-nn-text-muted">
                  {topic.timeEstimate}
                </td>
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-2 bg-nn-bg-page rounded-full overflow-hidden border border-nn-border">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${topic.mastery >= 90 ? 'bg-[#10B981]' : 'bg-[#3B6BFF]'}`}
                        style={{ width: `${topic.mastery}%` }}
                      />
                    </div>
                    <span className="text-xs font-medium w-8 text-nn-text-primary">
                      {topic.mastery === 100 ? <CheckCircle2 size={14} className="text-[#10B981]" /> : `${topic.mastery}%`}
                    </span>
                  </div>
                </td>
                <td className="px-5 py-4 text-right">
                  <button className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#3B6BFF]/10 text-[#3B6BFF] hover:bg-[#3B6BFF] hover:text-white transition-all group-hover:scale-110">
                    <Play size={14} className="ml-0.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}