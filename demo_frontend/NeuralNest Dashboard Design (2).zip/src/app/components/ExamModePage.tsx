import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Sparkles, Lock, X, Clock, BarChart2, Target, Calendar, UploadCloud, FileText, ChevronRight, Plus } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';

type NodeState = 'mastered' | 'active' | 'locked';

interface NodeData {
  id: string;
  label: string;
  state: NodeState;
  estimatedTime: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  mastery: number;
  x: number;
  y: number;
  pyqBadge?: string;
}

interface Edge {
  from: string;
  to: string;
}

const OS_NODES: NodeData[] = [
  { id: 'intro', label: 'Intro to OS', state: 'mastered', estimatedTime: '2 hrs', difficulty: 'Easy', mastery: 100, x: 400, y: 60 },
  { id: 'processes', label: 'Processes', state: 'mastered', estimatedTime: '4 hrs', difficulty: 'Medium', mastery: 100, x: 200, y: 180 },
  { id: 'threads', label: 'Threads', state: 'active', estimatedTime: '3 hrs', difficulty: 'Medium', mastery: 80, x: 400, y: 180 },
  { id: 'scheduling', label: 'CPU Scheduling', state: 'active', estimatedTime: '5 hrs', difficulty: 'Hard', mastery: 45, x: 620, y: 180, pyqBadge: '12 PYQ Qs' },
  { id: 'sync', label: 'Process Synchronization', state: 'locked', estimatedTime: '6 hrs', difficulty: 'Hard', mastery: 0, x: 200, y: 310, pyqBadge: '8 PYQ Qs' },
  { id: 'deadlocks', label: 'Deadlocks', state: 'locked', estimatedTime: '4 hrs', difficulty: 'Medium', mastery: 0, x: 400, y: 310 },
  { id: 'memory', label: 'Memory Management', state: 'locked', estimatedTime: '7 hrs', difficulty: 'Hard', mastery: 0, x: 620, y: 310, pyqBadge: '15 PYQ Qs' },
  { id: 'virtual', label: 'Virtual Memory', state: 'locked', estimatedTime: '5 hrs', difficulty: 'Medium', mastery: 0, x: 400, y: 430 },
  { id: 'fs', label: 'File Systems', state: 'locked', estimatedTime: '4 hrs', difficulty: 'Easy', mastery: 0, x: 620, y: 430 },
  { id: 'io', label: 'I/O Systems', state: 'locked', estimatedTime: '3 hrs', difficulty: 'Easy', mastery: 0, x: 400, y: 550 },
];

const OS_EDGES: Edge[] = [
  { from: 'intro', to: 'processes' },
  { from: 'intro', to: 'threads' },
  { from: 'intro', to: 'scheduling' },
  { from: 'processes', to: 'sync' },
  { from: 'threads', to: 'deadlocks' },
  { from: 'scheduling', to: 'memory' },
  { from: 'sync', to: 'deadlocks' },
  { from: 'deadlocks', to: 'virtual' },
  { from: 'memory', to: 'virtual' },
  { from: 'memory', to: 'fs' },
  { from: 'virtual', to: 'io' },
  { from: 'fs', to: 'io' }
];

const NODE_RADIUS = 28;

function nodeCenter(node: NodeData) {
  return { x: node.x + NODE_RADIUS, y: node.y + NODE_RADIUS };
}

function edgeColor(fromState: NodeState, toState: NodeState) {
  if (fromState === 'mastered' && toState === 'mastered') return '#10B981';
  if (fromState === 'mastered' && toState === 'active') return '#F59E0B';
  return 'var(--nn-border)';
}

function difficultyColor(d: string) {
  if (d === 'Easy') return '#10B981';
  if (d === 'Medium') return '#F59E0B';
  return '#EF4444';
}

function NodeCircle({ node, onClick }: { node: NodeData; onClick: (node: NodeData, e: React.MouseEvent) => void }) {
  const baseStyle: React.CSSProperties = {
    position: 'absolute',
    left: node.x,
    top: node.y,
    width: NODE_RADIUS * 2,
    height: NODE_RADIUS * 2,
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'transform 0.15s ease',
    userSelect: 'none',
  };

  let circleStyle: React.CSSProperties = {};
  if (node.state === 'mastered') {
    circleStyle = {
      background: '#10B981',
      boxShadow: '0 0 0 3px rgba(16,185,129,0.2), 0 0 16px rgba(16,185,129,0.3)',
    };
  } else if (node.state === 'active') {
    circleStyle = {
      background: '#F59E0B',
      boxShadow: '0 0 0 3px rgba(245,158,11,0.25), 0 0 20px rgba(245,158,11,0.5)',
      animation: 'pulseGlow 2s ease-in-out infinite',
    };
  } else {
    circleStyle = {
      background: 'var(--nn-bg-card)',
      border: '2px solid var(--nn-border)',
    };
  }

  return (
    <div style={{ position: 'absolute', left: node.x - 50 + NODE_RADIUS, top: node.y + NODE_RADIUS * 2 + 6, width: 100, textAlign: 'center', pointerEvents: 'none' }}>
      <div
        style={{ ...baseStyle, left: 50 - NODE_RADIUS, top: -(NODE_RADIUS * 2 + 6), ...circleStyle }}
        onClick={(e) => onClick(node, e)}
        onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.transform = 'scale(1.12)'; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.transform = 'scale(1)'; }}
      >
        {node.state === 'mastered' && <Check size={16} color="white" strokeWidth={3} />}
        {node.state === 'active' && <Sparkles size={16} color="white" strokeWidth={2} />}
        {node.state === 'locked' && <Lock size={14} color="var(--nn-text-muted)" strokeWidth={2} />}
        
        {node.pyqBadge && (
          <div style={{
            position: 'absolute',
            top: -10,
            right: -24,
            background: '#F97316',
            color: 'white',
            fontSize: '9px',
            fontWeight: 'bold',
            padding: '3px 7px',
            borderRadius: '12px',
            whiteSpace: 'nowrap',
            boxShadow: '0 2px 8px rgba(249,115,22,0.4)',
            zIndex: 10,
            border: '1px solid rgba(255,255,255,0.2)'
          }}>
            {node.pyqBadge}
          </div>
        )}
      </div>
      <span style={{ fontSize: 11, color: 'var(--nn-text-muted)', lineHeight: 1.3, display: 'block', marginTop: 2 }}>{node.label}</span>
    </div>
  );
}

// Reusing PopupCard implementation...
function PopupCard({ node, worldX, worldY, onClose, onStartLearning }: any) {
  const stateLabel = node.state === 'mastered' ? 'Mastered' : node.state === 'active' ? 'In Progress' : 'Locked';
  const stateColor = node.state === 'mastered' ? '#10B981' : node.state === 'active' ? '#F59E0B' : '#6B7280';
  const stateBg = node.state === 'mastered' ? 'rgba(16,185,129,0.12)' : node.state === 'active' ? 'rgba(245,158,11,0.12)' : 'rgba(107,114,128,0.12)';

  return (
    <div
      style={{
        position: 'absolute',
        left: worldX,
        top: worldY,
        width: 240,
        background: 'var(--nn-bg-card)',
        border: '1px solid var(--nn-border)',
        borderRadius: 14,
        padding: 18,
        zIndex: 100,
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        pointerEvents: 'all',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
        <span style={{ color: 'var(--nn-text-primary)', fontWeight: 700, fontSize: 14, lineHeight: 1.3, flex: 1, paddingRight: 8 }}>{node.label}</span>
        <button
          onClick={onClose}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--nn-text-muted)', padding: 2, flexShrink: 0 }}
        >
          <X size={15} />
        </button>
      </div>

      <span style={{ display: 'inline-block', background: stateBg, color: stateColor, border: `1px solid ${stateColor}40`, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600, marginBottom: 14 }}>
        {stateLabel}
      </span>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Clock size={13} color="var(--nn-text-muted)" />
          <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>Estimated: <span style={{ color: 'var(--nn-text-primary)' }}>{node.estimatedTime}</span></span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <BarChart2 size={13} color="var(--nn-text-muted)" />
          <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>Difficulty: <span style={{ color: difficultyColor(node.difficulty) }}>{node.difficulty}</span></span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Target size={13} color="var(--nn-text-muted)" />
            <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>Mastery: <span style={{ color: 'var(--nn-text-primary)' }}>{node.mastery}%</span></span>
          </div>
          <div style={{ background: 'var(--nn-border)', borderRadius: 4, height: 5, overflow: 'hidden', marginLeft: 21 }}>
            <div style={{ width: `${node.mastery}%`, height: '100%', background: node.mastery === 100 ? '#10B981' : '#3B6BFF', borderRadius: 4, transition: 'width 0.4s ease' }} />
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <button
          onClick={onStartLearning}
          style={{ width: '100%', background: '#3B6BFF', border: 'none', borderRadius: 10, padding: '9px 0', color: 'white', fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'background 0.15s' }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = '#2A57E5'; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = '#3B6BFF'; }}
        >
          Start Learning
        </button>
        <button
          style={{ width: '100%', background: 'transparent', border: '1.5px solid #3B6BFF', borderRadius: 10, padding: '9px 0', color: '#3B6BFF', fontSize: 13, fontWeight: 600, cursor: 'pointer', transition: 'background 0.15s' }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(59,107,255,0.08)'; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
        >
          Test my Skills
        </button>
      </div>
    </div>
  );
}

function ExamRoadmapView() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(0.85);
  const [pan, setPan] = useState({ x: 40, y: 20 });
  const [dragging, setDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [selectedNode, setSelectedNode] = useState<NodeData | null>(null);
  const [popupPos, setPopupPos] = useState({ x: 0, y: 0 });
  const dragThreshold = useRef(false);

  const nodeMap = Object.fromEntries(OS_NODES.map(n => [n.id, n]));

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.08 : 0.08;
    setZoom(z => Math.min(2.0, Math.max(0.3, z + delta)));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setDragging(true);
    dragThreshold.current = false;
    setDragStart({ x: e.clientX, y: e.clientY });
    setPanStart({ ...pan });
  }, [pan]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!dragging) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragThreshold.current = true;
    setPan({ x: panStart.x + dx, y: panStart.y + dy });
  }, [dragging, dragStart, panStart]);

  const handleMouseUp = useCallback(() => {
    setDragging(false);
  }, []);

  const handleNodeClick = useCallback((node: NodeData, e: React.MouseEvent) => {
    e.stopPropagation();
    if (dragThreshold.current) return;
    const center = nodeCenter(node);
    setPopupPos({ x: center.x + 36, y: center.y - 20 });
    setSelectedNode(node);
  }, []);

  const handleCanvasClick = useCallback(() => {
    setSelectedNode(null);
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedNode(null);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const worldWidth = 980;
  const worldHeight = 700;

  return (
    <div className="flex-1 flex flex-col min-w-0">
      <div style={{ padding: '16px 24px 8px', borderBottom: '1px solid var(--nn-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--nn-bg-page)', flexShrink: 0 }}>
        <div>
          <p style={{ fontSize: 11, color: 'var(--nn-text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 2 }}>Exam Mode</p>
          <h1 style={{ fontSize: 20, fontWeight: 700, color: 'var(--nn-text-primary)' }}>Operating Systems Exam Roadmap</h1>
        </div>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 12 }}>
            {[
              { color: '#10B981', label: 'Mastered' },
              { color: '#F59E0B', label: 'In Progress' },
              { color: 'var(--nn-border)', label: 'Locked', border: '2px solid var(--nn-text-muted)' },
            ].map(({ color, label, border }) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 12, height: 12, borderRadius: '50%', background: color, border }} />
                <span style={{ fontSize: 12, color: 'var(--nn-text-muted)' }}>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div
        ref={containerRef}
        style={{ flex: 1, position: 'relative', overflow: 'hidden', cursor: dragging ? 'grabbing' : 'grab', background: 'var(--nn-bg-page)' }}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={handleCanvasClick}
      >
        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
          <defs>
            <pattern id="dots2" x={pan.x % (20 * zoom)} y={pan.y % (20 * zoom)} width={20 * zoom} height={20 * zoom} patternUnits="userSpaceOnUse">
              <circle cx={1} cy={1} r={1} fill="var(--nn-border)" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dots2)" />
        </svg>

        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            transformOrigin: '0 0',
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            width: worldWidth,
            height: worldHeight,
          }}
        >
          <svg
            style={{ position: 'absolute', top: 0, left: 0, width: worldWidth, height: worldHeight, overflow: 'visible', pointerEvents: 'none' }}
          >
            <defs>
              <marker id="arrow-green2" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#10B981" />
              </marker>
              <marker id="arrow-amber2" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#F59E0B" />
              </marker>
              <marker id="arrow-gray2" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="var(--nn-border)" />
              </marker>
            </defs>
            {OS_EDGES.map((edge) => {
              const fromNode = nodeMap[edge.from];
              const toNode = nodeMap[edge.to];
              if (!fromNode || !toNode) return null;
              const fc = nodeCenter(fromNode);
              const tc = nodeCenter(toNode);
              const dx = tc.x - fc.x;
              const dy = tc.y - fc.y;
              const len = Math.sqrt(dx * dx + dy * dy);
              const ux = dx / len;
              const uy = dy / len;
              const sx = fc.x + ux * NODE_RADIUS;
              const sy = fc.y + uy * NODE_RADIUS;
              const ex = tc.x - ux * (NODE_RADIUS + 7);
              const ey = tc.y - uy * (NODE_RADIUS + 7);
              const mx = (sx + ex) / 2 - uy * 20;
              const my = (sy + ey) / 2 + ux * 20;
              const color = edgeColor(fromNode.state, toNode.state);
              const markerId = color === '#10B981' ? 'arrow-green2' : color === '#F59E0B' ? 'arrow-amber2' : 'arrow-gray2';
              return (
                <path
                  key={`${edge.from}-${edge.to}`}
                  d={`M ${sx} ${sy} Q ${mx} ${my} ${ex} ${ey}`}
                  stroke={color}
                  strokeWidth={2}
                  fill="none"
                  opacity={color === 'var(--nn-border)' ? 0.6 : 0.85}
                  markerEnd={`url(#${markerId})`}
                />
              );
            })}
          </svg>

          {OS_NODES.map(node => (
            <NodeCircle key={node.id} node={node} onClick={handleNodeClick} />
          ))}

          {selectedNode && (
            <PopupCard
              node={selectedNode}
              worldX={popupPos.x}
              worldY={popupPos.y}
              onClose={() => setSelectedNode(null)}
              onStartLearning={() => {}}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export function ExamModePage() {
  const [isGenerated, setIsGenerated] = useState(false);
  const [step, setStep] = useState(1);

  const steps = ["Exam Details", "Syllabus", "PYQs"];

  return (
    <div className="flex h-screen bg-nn-bg-page text-nn-text-primary overflow-hidden font-['Inter'] selection:bg-[#3B6BFF] selection:text-white transition-colors">
      <style>{`
        @keyframes pulseGlow {
          0%, 100% { box-shadow: 0 0 0 3px rgba(245,158,11,0.25), 0 0 20px rgba(245,158,11,0.5); }
          50% { box-shadow: 0 0 0 6px rgba(245,158,11,0.15), 0 0 32px rgba(245,158,11,0.7); }
        }
      `}</style>
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar />
        
        {isGenerated ? (
          <ExamRoadmapView />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-6 overflow-y-auto">
            
            {/* Step Progress Indicator */}
            <div className="flex items-center gap-2 mb-10">
              {steps.map((s, idx) => {
                const stepNum = idx + 1;
                const isActive = step === stepNum;
                const isCompleted = step > stepNum;
                
                return (
                  <div key={s} className="flex items-center gap-2">
                    <div className={`flex items-center justify-center px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
                      isActive ? 'bg-[#3B6BFF] border-[#3B6BFF] text-white' :
                      isCompleted ? 'bg-nn-bg-card border-[#3B6BFF] text-[#3B6BFF]' :
                      'bg-nn-bg-card border-nn-border text-nn-text-muted'
                    }`}>
                      {isCompleted ? <Check size={12} strokeWidth={3} className="mr-1.5" /> : <span className="mr-1.5">{stepNum}.</span>}
                      {s}
                    </div>
                    {idx < steps.length - 1 && (
                      <div className="w-8 h-[1px] bg-nn-border transition-colors"></div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Setup Cards */}
            <div className="w-full max-w-[520px] bg-nn-bg-card border border-nn-border rounded-2xl p-8 shadow-sm relative transition-colors">
              
              {step === 1 && (
                <div className="flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
                  <div className="w-12 h-12 rounded-xl bg-nn-bg-sidebar flex items-center justify-center border border-nn-border mb-5 transition-colors">
                    <Calendar size={24} className="text-[#3B6BFF]" />
                  </div>
                  <h2 className="text-2xl font-bold text-nn-text-primary mb-6">Set Up Your Exam</h2>
                  
                  <div className="space-y-5">
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium text-nn-text-muted">What subject is your exam for?</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Operating Systems, Anatomy, Economics" 
                        defaultValue="Operating Systems"
                        className="w-full bg-nn-bg-page border border-nn-border rounded-xl px-4 py-3 text-nn-text-primary placeholder-nn-text-muted focus:outline-none focus:border-[#3B6BFF] transition-colors text-[15px]"
                      />
                    </div>
                    
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium text-nn-text-muted">When is your exam?</label>
                      <input 
                        type="date" 
                        className="w-full bg-nn-bg-page border border-nn-border rounded-xl px-4 py-3 text-nn-text-primary focus:outline-none focus:border-[#3B6BFF] transition-colors text-[15px] [color-scheme:light] dark:[color-scheme:dark]"
                      />
                      <p className="text-sm text-[#10B981] font-medium mt-1">You have 5 days left</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-end mt-8">
                    <button 
                      onClick={() => setStep(2)}
                      className="bg-[#3B6BFF] hover:bg-[#2A57E5] text-white px-6 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2"
                    >
                      Next
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
                  <div className="w-12 h-12 rounded-xl bg-nn-bg-sidebar flex items-center justify-center border border-nn-border mb-5 transition-colors">
                    <FileText size={24} className="text-[#3B6BFF]" />
                  </div>
                  <h2 className="text-2xl font-bold text-nn-text-primary mb-6">Syllabus</h2>
                  
                  <div className="w-full border-2 border-dashed border-[#3B6BFF]/40 rounded-2xl bg-[#3B6BFF]/5 hover:bg-[#3B6BFF]/10 transition-colors flex flex-col items-center justify-center py-10 cursor-pointer mb-4">
                    <div className="w-12 h-12 rounded-full bg-[#3B6BFF]/20 flex items-center justify-center mb-4">
                      <Plus size={24} className="text-[#3B6BFF]" />
                    </div>
                    <p className="text-[15px] font-medium text-nn-text-primary mb-1">Drop your syllabus PDF here</p>
                    <p className="text-sm text-nn-text-muted">or click to browse files</p>
                  </div>
                  
                  <button className="text-[14px] text-[#3B6BFF] font-medium hover:underline self-start">
                    Skip — let AI find the syllabus online
                  </button>
                  
                  <div className="flex justify-end gap-3 mt-8">
                    <button 
                      onClick={() => setStep(3)}
                      className="px-6 py-2.5 rounded-xl font-semibold transition-colors text-nn-text-muted hover:text-nn-text-primary hover:bg-nn-bg-sidebar"
                    >
                      Skip
                    </button>
                    <button 
                      onClick={() => setStep(3)}
                      className="bg-[#3B6BFF] hover:bg-[#2A57E5] text-white px-6 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2"
                    >
                      Next
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
                  <div className="w-12 h-12 rounded-xl bg-nn-bg-sidebar flex items-center justify-center border border-nn-border mb-5 transition-colors">
                    <Target size={24} className="text-[#3B6BFF]" />
                  </div>
                  <h2 className="text-2xl font-bold text-nn-text-primary mb-6">Previous Year Questions (PYQ)</h2>
                  
                  <div className="w-full border-2 border-dashed border-nn-border rounded-2xl bg-nn-bg-page hover:bg-nn-bg-sidebar transition-colors flex flex-col items-center justify-center py-10 cursor-pointer mb-4">
                    <div className="w-12 h-12 rounded-full bg-nn-border flex items-center justify-center mb-4 transition-colors">
                      <Plus size={24} className="text-nn-text-muted" />
                    </div>
                    <p className="text-[15px] font-medium text-nn-text-primary mb-1">Drop your PYQ PDF here</p>
                    <p className="text-sm text-nn-text-muted">or click to browse files</p>
                  </div>
                  
                  <p className="text-[13px] text-nn-text-muted leading-relaxed">
                    AI will analyze how many times each topic appears to prioritize your study plan.
                  </p>
                  
                  <div className="flex justify-end gap-3 mt-8">
                    <button 
                      onClick={() => setIsGenerated(true)}
                      className="px-6 py-2.5 rounded-xl font-semibold transition-colors text-nn-text-muted hover:text-nn-text-primary hover:bg-nn-bg-sidebar"
                    >
                      Skip
                    </button>
                    <button 
                      onClick={() => setIsGenerated(true)}
                      className="bg-[#3B6BFF] hover:bg-[#2A57E5] text-white px-6 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2"
                    >
                      Generate Roadmap
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}
      </div>
    </div>
  );
}