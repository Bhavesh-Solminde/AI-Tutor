import React from 'react';
import { MemoryRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { DashboardContent } from './components/DashboardContent';
import { RoadmapPage } from './components/RoadmapPage';
import { QuizPage } from './components/QuizPage';
import { AITutorPage } from './components/AITutorPage';
import { ExamModePage } from './components/ExamModePage';

function DashboardPage() {
  return (
    <div className="flex h-screen bg-nn-bg-page text-nn-text-primary overflow-hidden font-['Inter'] selection:bg-[#3B6BFF] selection:text-white transition-colors">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar />
        <main className="flex-1 overflow-y-auto p-6 scrollbar-hide">
          <DashboardContent />
        </main>
      </div>
    </div>
  );
}

export default function App() {
  React.useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  return (
    <MemoryRouter initialEntries={['/']}>
      <Routes>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/roadmap" element={<RoadmapPage />} />
        <Route path="/ai-tutor" element={<AITutorPage />} />
        <Route path="/exam-mode" element={<ExamModePage />} />
        <Route path="/quiz" element={<QuizPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </MemoryRouter>
  );
}