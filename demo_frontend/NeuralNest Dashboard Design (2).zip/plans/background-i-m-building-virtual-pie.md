# Plan: NeuralNest Roadmap Page

## Context
The NeuralNest dashboard already has a complete Dashboard page. The Sidebar has a "Roadmap" nav item that currently does nothing. This plan adds a Roadmap page — a zoomable node-graph canvas — keeping the same Sidebar and TopBar shell.

## Routing

React Router v7 is installed but unused. Wire it up minimally:
- `App.tsx`: Wrap with `<BrowserRouter>`, render `<Routes>` switching between `/` (Dashboard) and `/roadmap` (Roadmap).
- Sidebar "Roadmap" button: navigate to `/roadmap`; "Dashboard" button: navigate to `/`.
- Active nav item highlight driven by `useLocation()`.

**Files to touch:** `src/app/App.tsx`, `src/app/components/Sidebar.tsx`

## RoadmapPage Component

New file: `src/app/components/RoadmapPage.tsx`

### Canvas / Zoom-Pan
- Use a `<canvas>`-less approach: a `<div>` container with `overflow: hidden` and an inner "world" `<div>` that gets CSS `transform: scale(zoom) translate(panX, panY)`.
- Wheel event → zoom in/out (clamp 0.4–2.0).
- Mouse drag on the canvas background → pan.
- Touch events not required.
- SVG `<svg>` layer absolutely positioned behind nodes to draw directional arrows between connected nodes (quadratic bezier curves with `<marker>` arrowheads).

### Node Data
Hard-code ~16 nodes in a tree/DAG layout (x, y in "world" coordinates). Each node has:
```ts
{ id, label, state: 'mastered' | 'active' | 'locked', estimatedTime, difficulty, mastery, description }
```
Edges array: `{ from, to }` pairs.

Sample topic tree (Physics-flavored to match existing dashboard):
- Root: "Classical Mechanics" (mastered) → "Kinematics" (mastered) → "Dynamics" (mastered)
- "Dynamics" → "Work & Energy" (active) → "Momentum" (locked) → "Rotational Motion" (locked)
- "Classical Mechanics" → "Waves & Oscillations" (active) → "Sound" (locked)
- "Waves & Oscillations" → "Optics" (locked)
- Separate branch: "Thermodynamics" (mastered) → "Kinetic Theory" (active) → "Laws of Thermodynamics" (locked)
- "Electricity" (locked) → "Magnetism" (locked) → "Electromagnetic Waves" (locked)

### Node Visuals
Rendered as absolutely-positioned `<div>` circles (56px diameter):
- **Mastered** (`state === 'mastered'`): solid `#10B981` fill, white checkmark icon (Lucide `Check`), subtle green glow box-shadow.
- **Active** (`state === 'active'`): solid `#F59E0B` fill with `box-shadow: 0 0 16px 4px rgba(245,158,11,0.5)` pulsing glow (CSS keyframe animation), white `Sparkles` icon.
- **Locked** (`state === 'locked'`): `#2A2A3E` fill, `#6B7280` border, gray `Lock` icon.

Label text below each circle (centered, 12px, white, max-width ~80px).

### Edges (SVG Arrows)
Single `<svg>` fills the world div. For each edge compute start/end points at node centers, draw a `<path>` with a slight curve. Use `<defs><marker id="arrow">` for arrowheads. Color: mastered→mastered = `#10B981`, anything else = `#2A2A3E` with low opacity.

### Popup Card (inline)
State: `selectedNode: NodeData | null`. When a node is clicked (and not dragging), show a popup card positioned near the node (offset so it doesn't overlap).

Card design (matches dashboard card style):
- Background `#1E1E2C`, border `1px solid #2A2A3E`, border-radius 12px, padding 20px, width 240px.
- **Header**: topic name (bold white, 15px) + `×` close button.
- **Status badge**: pill badge colored by state (green/yellow/gray).
- **Info rows**: `⏱ Estimated: X hours`, `📊 Difficulty: Easy/Medium/Hard`, `🎯 Mastery: X%` with a mini progress bar.
- **Buttons** (stacked, full width):
  1. "Start Learning" — solid `#3B6BFF` bg, white text.
  2. "Test my Skills" — transparent bg, `#3B6BFF` border and text.
- Close on `Escape` key or clicking outside.

Popup position: clamp to stay within viewport using a `useEffect` that adjusts translate after render.

### Controls Overlay
Bottom-right of the canvas (fixed within the container):
- `+` zoom in, `-` zoom out, reset/fit button (home icon).

### Page Layout
Same shell as Dashboard:
```
<div style={{ display: 'flex', height: '100vh', background: '#16161F' }}>
  <Sidebar />
  <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
    <TopBar />
    <RoadmapCanvas />   ← fills remaining height
  </div>
</div>
```

## Files to Create / Modify

| File | Action |
|------|--------|
| `src/app/App.tsx` | Add BrowserRouter + Routes for `/` and `/roadmap` |
| `src/app/components/Sidebar.tsx` | Use `useNavigate` + `useLocation` for active state and navigation |
| `src/app/components/RoadmapPage.tsx` | New — full roadmap canvas + popup |

## QuizPage Component

New file: `src/app/components/QuizPage.tsx`

### Page Header
Full-width header row (inside main content area, below TopBar):
- **Left**: back arrow (`ChevronLeft` icon, clickable → navigates back) + purple pill label "PRACTICE MODULE" (`#7C3AED` bg, white text, 11px uppercase) + "Topic Mastery Quiz" title (bold white, 22px).
- **Right**: 5 red heart icons (`Heart` from Lucide, filled `#EF4444`) representing lives + amber XP counter badge (`#F59E0B` bg, dark text, e.g. "⚡ 340 XP").

Add route `/quiz` in `App.tsx`. Sidebar "Quiz" nav item (if present) navigates there; alternatively the "Test my Skills" button on the Roadmap popup can also link here.

### Quiz Steps Panel (left column, ~200px wide)
Titled "QUIZ STEPS" in small muted uppercase. Numbered list of 5–6 questions:
- Each item: circle number + short question label (e.g. "Q1 · Newton's Laws").
- **Current question**: blue-highlighted background (`#3B6BFF` bg tint), bold text.
- **Completed questions**: green checkmark instead of number.
- **Upcoming**: muted gray number.

### Main Question Area (right, flex-1)
Card (`#1E1E2C` bg, `#2A2A3E` border, 16px border-radius):
- Question text in bold white (18px), e.g. "Which of the following best describes Newton's Second Law of Motion?"
- 4 answer option cards stacked vertically, each `#16161F` bg with `#2A2A3E` border, 12px radius, 16px padding, letter prefix (A/B/C/D) in a small circle.
  - **Default state**: neutral border.
  - **Selected/Correct state**: green border (`#10B981`), very subtle green tint background (`rgba(16,185,129,0.08)`), green `CheckCircle` icon on the right.
  - **Selected/Wrong state**: red border (`#EF4444`), red tint, `XCircle` icon (for future extension; not required for the static correct-answer demo).
- Pre-select the correct answer (option B or C) to show the result state without interaction complexity. Allow clicking options to toggle selection.

### Bottom Feedback Bar
Full-width bar pinned to the bottom of the main content area (`#1E1E2C` bg, top border `#2A2A3E`):
- **Left**: green `CheckCircle` icon + "Correct! You gained **+20 XP**" text (white, 15px).
- **Right**: solid blue "Continue →" button (`#3B6BFF`, white text, rounded, `ArrowRight` icon).

### Layout
```
<div style={{ display: 'flex', height: '100vh', background: '#16161F' }}>
  <Sidebar />
  <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
    <TopBar />
    <QuizContent />   ← flex-1 with internal scroll
  </div>
</div>
```

## Files to Create / Modify (Full List)

| File | Action |
|------|--------|
| `src/app/App.tsx` | Add BrowserRouter + Routes for `/`, `/roadmap`, `/quiz` |
| `src/app/components/Sidebar.tsx` | `useNavigate` + `useLocation` for active state |
| `src/app/components/RoadmapPage.tsx` | New — zoomable node graph |
| `src/app/components/QuizPage.tsx` | New — quiz UI |

## Verification
1. Click "Roadmap" in sidebar → canvas page loads.
2. Scroll wheel zooms in/out; drag pans the graph.
3. Clicking a mastered node → popup shows green badge, 100% mastery, "Start Learning" + "Test my Skills" buttons.
4. Clicking an active node → yellow badge, partial mastery.
5. Clicking a locked node → gray badge, 0% mastery.
6. Clicking outside popup or pressing Escape closes it.
7. Zoom controls (+/−/reset) work.
8. Clicking "Dashboard" in sidebar returns to the main dashboard.
9. Clicking `/quiz` route renders Quiz page with header, steps panel, question card, and feedback bar.
10. Clicking an answer option toggles selection; correct answer shows green border + checkmark.
11. Lives (hearts) and XP counter display correctly in header.
